# Template database: orange traffic cones and construction signs

Source: Mapillary Vistas v2.0, research edition (hand-drawn instance masks), training + validation splits.
Built 2026-10-30 by build_datasets.py. Vistas is licensed for non-commercial
research use; keep this repo private and cite Neuhold et al., ICCV 2017.

Classes: cone = `object--traffic-cone`, sign = `object--traffic-sign--temporary-front`.

Each object is one template: `crops/<class>/*.png` (bounding-box crop) and `masks/<class>/*.png`
(object pixels, eroded 2 px). Compute histograms on mask pixels only. `templates.csv` lists them;
`role` splits templates from held-out validation crops by source image (30% validation).

Filters: bounding box at least 24px per side; at least 500 mask pixels after erosion;
orange share of mask pixels at least 0.25 (cone) / 0.4 (sign), where orange means
Lab hue 42-75 deg and chroma > 30. This removes the red/white and yellow
work-zone styles used outside the US.

| class | templates | validation | rejected: too small | too few pixels | not orange |
|---|---|---|---|---|---|
| cone | 243 | 77 | 2629 | 394 | 2514 |
| sign | 47 | 35 | 156 | 49 | 701 |
